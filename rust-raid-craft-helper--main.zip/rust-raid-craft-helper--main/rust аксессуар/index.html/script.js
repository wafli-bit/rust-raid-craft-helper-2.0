
const RECIPES = {
  Gunpowder:   { yield: 10, comps: { Charcoal: 30, Sulfur: 20 } },
  Explosives:  { yield: 1,  comps: { Gunpowder: 50, "Low Grade Fuel": 3, Sulfur: 10, "Metal Fragments": 10 } },
  Rocket:      { yield: 1,  comps: { Explosives: 10, Gunpowder: 150, "Metal Pipe": 2 } },
  C4:          { yield: 1,  comps: { Explosives: 20, Cloth: 10, "Tech Trash": 5 } },
  Beancan:     { yield: 1,  comps: { Gunpowder: 60, "Metal Fragments": 20 } },
  Satchel:     { yield: 1,  comps: { Beancan: 4, Rope: 1, "Small Stash": 1 } },
  Explo556:    { yield: 1,  comps: { Gunpowder: 10, Sulfur: 5, "Metal Fragments": 5 } },
  Syringe:     { yield: 1,  comps: { Cloth: 15, "Metal Fragments": 10, "Low Grade Fuel": 10 } },
  Bandage:     { yield: 1,  comps: { Cloth: 3 } },
  SleepingBag: { yield: 1,  comps: { Cloth: 1 } },
};

const RES_LABEL = {
  Sulfur: "Сера", Charcoal: "Уголь", Cloth: "Ткань",
  "Metal Fragments": "Металл. фрагменты", "Low Grade Fuel": "Топливо (низк. кач.)",
  "Metal Pipe": "Металлическая труба", "Tech Trash": "Тех. хлам",
  Rope: "Верёвка", "Small Stash": "Малый тайник",
};


function resolve(key, qty, acc = {}) {
  const recipe = RECIPES[key];
  if (!recipe) { acc[key] = (acc[key] || 0) + qty; return acc; }
  const crafts = Math.ceil(qty / recipe.yield);
  for (const [comp, amount] of Object.entries(recipe.comps)) {
    resolve(comp, amount * crafts, acc);
  }
  return acc;
}


const TARGETS = {
  wood:    { label: "Деревянная стена / дверь",        c4: 1, rocket: 2,  satchel: 5,  explo556: 93  },
  stone:   { label: "Каменная стена (Stone Wall)",      c4: 2, rocket: 4,  satchel: 10, explo556: 185 },
  metal:   { label: "Металлическая стена (Sheet Metal)",c4: 4, rocket: 8,  satchel: 20, explo556: 370 },
  armored: { label: "Бронированная стена (HQM)",        c4: 8, rocket: 16, satchel: 40, explo556: 740 },
  metaldoor:  { label: "Металлическая дверь",           c4: 1, rocket: 1,  satchel: 3,  explo556: 63  },
  garage:     { label: "Гаражная дверь",                c4: 2, rocket: 3,  satchel: 5,  explo556: 150 },
  armoreddoor:{ label: "Бронированная дверь",           c4: 3, rocket: 5,  satchel: 15, explo556: 280 },
  tc:         { label: "Шкаф-инструментов (TC)",        c4: 1, rocket: 2,  satchel: 4,  explo556: 70  },
  turret:     { label: "Авто-турель",                   c4: 1, rocket: 1,  satchel: 2,  explo556: 50  },
};

const EXPLOSIVE_MAP = {
  c4:       { key: "C4",       label: "C4 (Заряд)" },
  rocket:   { key: "Rocket",   label: "Ракета" },
  satchel:  { key: "Satchel",  label: "Сатчель" },
  explo556: { key: "Explo556", label: "Разрывной 5.56 (за патрон)" },
};

const CRAFT_ITEMS = {
  Rocket:      "Ракета",
  C4:          "C4 (Заряд)",
  Satchel:     "Сатчель",
  Beancan:     "Граната Бинкен (Beancan)",
  Explo556:    "Разрывной патрон 5.56 (1 шт)",
  Gunpowder:   "Порох (Gunpowder)",
  Syringe:     "Медицинский шприц",
  Bandage:     "Бинт (Bandage)",
  SleepingBag: "Спальный мешок",
};

const CHECKLIST_DATA = [
  { title: "Оружие и патроны", items: [
    "Основное оружие (ТТ / винтовка) + запасной магазин",
    "Патроны — минимум 2 стака в стеке",
    "Дробовик как ближний резерв + картечь",
    "Пистолет как страховочное оружие",
  ]},
  { title: "Медицина", items: [
    "Медицинские шприцы (от 5 шт на человека)",
    "Бинты про запас",
    "Большая аптечка",
  ]},
  { title: "Взрывчатка и инструменты", items: [
    "Взрывчатка по текущему плану рейда",
    "Ракетница (если берёте ракеты)",
    "Запасной сатчель / разрывные патроны",
    "Кирка / топор для зачистки завалов",
  ]},
  { title: "Защита и позиция", items: [
    "Броня (кольчуга / раид-костюм)",
    "Шлем",
    "Турель прикрытия + патроны к ней",
    "Лестницы (приставные / деревянные)",
    "Спальные мешки (точки возрождения рядом)",
  ]},
  { title: "Связь и логистика", items: [
    "Рация для связи с кланом",
    "Стройматериалы для баррикад/лестниц",
    "Факел или фонарь",
    "Ключ / код от шкафа-инструментов цели",
  ]},
];

/* =========================================================
   STATE
   ========================================================= */
let raidPlan = []; // { id, targetKey, count, expKey }

/* =========================================================
   INIT
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
  initTabs();
  initTargetSelect();
  initCraftSelect();
  initChecklist();

  document.getElementById("targetSelect").addEventListener("change", renderCompare);
  document.getElementById("targetCount").addEventListener("input", renderCompare);
  document.getElementById("addToPlanBtn").addEventListener("click", addToPlan);
  document.getElementById("clearPlanBtn").addEventListener("click", clearPlan);
  document.getElementById("calcCraftBtn").addEventListener("click", calcCraft);
  document.getElementById("resetChecklistBtn").addEventListener("click", resetChecklist);

  renderCompare();
  renderPlan();
});

/* ---------- Tabs ---------- */
function initTabs() {
  const buttons = document.querySelectorAll(".tab-btn");
  buttons.forEach(btn => {
    btn.addEventListener("click", () => {
      buttons.forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
    });
  });
}


function initTargetSelect() {
  const sel = document.getElementById("targetSelect");
  sel.innerHTML = Object.entries(TARGETS)
    .map(([key, t]) => `<option value="${key}">${t.label}</option>`)
    .join("");
}


function renderCompare() {
  const targetKey = document.getElementById("targetSelect").value;
  const count = Math.max(1, parseInt(document.getElementById("targetCount").value) || 1);
  const target = TARGETS[targetKey];
  if (!target) return;

  const rows = Object.entries(EXPLOSIVE_MAP).map(([expType, exp]) => {
    const unitsPerTarget = target[expType];
    const totalUnits = unitsPerTarget * count;
    const raw = resolve(exp.key, totalUnits);
    return {
      expType, label: exp.label, units: totalUnits,
      sulfur: raw.Sulfur || 0, charcoal: raw.Charcoal || 0,
    };
  });

  const cheapest = rows.reduce((a, b) => (b.sulfur < a.sulfur ? b : a));

  const box = document.getElementById("compareTable");
  box.innerHTML = rows.map(r => `
    <div class="compare-row ${r.expType === cheapest.expType ? "best" : ""}">
      <div class="method-name">${r.label}${r.expType === cheapest.expType ? '<span class="best-tag">Дешевле</span>' : ""}</div>
      <div><span class="stat-label">Кол-во</span><span class="stat-value">${r.units}</span></div>
      <div><span class="stat-label">Сера</span><span class="stat-value sulfur-val">${r.sulfur.toLocaleString("ru-RU")}</span></div>
      <div><span class="stat-label">Уголь</span><span class="stat-value charcoal-val">${r.charcoal.toLocaleString("ru-RU")}</span></div>
    </div>
  `).join("");
}


function addToPlan() {
  const targetKey = document.getElementById("targetSelect").value;
  const count = Math.max(1, parseInt(document.getElementById("targetCount").value) || 1);
  const expKey = document.getElementById("explosiveSelect").value;
  raidPlan.push({ id: Date.now() + Math.random(), targetKey, count, expKey });
  renderPlan();
}

function removeFromPlan(id) {
  raidPlan = raidPlan.filter(p => p.id !== id);
  renderPlan();
}

function clearPlan() {
  raidPlan = [];
  renderPlan();
}

function renderPlan() {
  const list = document.getElementById("planList");
  const totalsBox = document.getElementById("planTotals");

  if (raidPlan.length === 0) {
    list.innerHTML = `<p class="empty-hint">План пуст — добавьте цели выше.</p>`;
    totalsBox.innerHTML = "";
    return;
  }

  let grandSulfur = 0, grandCharcoal = 0, grandUnits = 0;

  list.innerHTML = raidPlan.map(p => {
    const target = TARGETS[p.targetKey];
    const exp = EXPLOSIVE_MAP[p.expKey];
    const units = target[p.expKey] * p.count;
    const raw = resolve(exp.key, units);
    const sulfur = raw.Sulfur || 0;
    const charcoal = raw.Charcoal || 0;

    grandSulfur += sulfur;
    grandCharcoal += charcoal;
    grandUnits += units;

    return `
      <div class="plan-item">
        <div>
          <div class="pi-name">${target.label} × ${p.count}</div>
          <div class="pi-sub">${exp.label}</div>
        </div>
        <div class="pi-metric"><span class="stat-label">Кол-во</span>${units}</div>
        <div class="pi-metric"><span class="stat-label">Сера</span>${sulfur.toLocaleString("ru-RU")}</div>
        <div class="pi-metric"><span class="stat-label">Уголь</span>${charcoal.toLocaleString("ru-RU")}</div>
        <button class="btn-icon" onclick="removeFromPlan(${p.id})" title="Удалить">✕</button>
      </div>
    `;
  }).join("");

  totalsBox.innerHTML = `
    <div class="total-box rust"><div class="tb-label">Взрывчатки всего</div><div class="tb-value">${grandUnits}</div></div>
    <div class="total-box sulfur"><div class="tb-label">Сера</div><div class="tb-value">${grandSulfur.toLocaleString("ru-RU")}</div></div>
    <div class="total-box charcoal"><div class="tb-label">Уголь</div><div class="tb-value">${grandCharcoal.toLocaleString("ru-RU")}</div></div>
    <div class="total-box"><div class="tb-label">Целей в плане</div><div class="tb-value">${raidPlan.length}</div></div>
  `;
}


function initCraftSelect() {
  const sel = document.getElementById("craftItemSelect");
  sel.innerHTML = Object.entries(CRAFT_ITEMS)
    .map(([key, label]) => `<option value="${key}">${label}</option>`)
    .join("");
}

function calcCraft() {
  const key = document.getElementById("craftItemSelect").value;
  const qty = Math.max(1, parseInt(document.getElementById("craftCount").value) || 1);
  const label = CRAFT_ITEMS[key];
  const raw = resolve(key, qty);

  const rows = Object.entries(raw)
    .sort((a, b) => b[1] - a[1])
    .map(([res, amount]) => `
      <tr>
        <td>${RES_LABEL[res] || res}</td>
        <td class="res-amount">${Math.ceil(amount).toLocaleString("ru-RU")}</td>
      </tr>
    `).join("");

  document.getElementById("craftResult").innerHTML = `
    <div class="craft-summary">Расчёт на <b>${qty}× ${label}</b></div>
    <table>
      <thead><tr><th>Ресурс</th><th style="text-align:right">Кол-во</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  `;
}


const CHECKLIST_STORAGE_KEY = "rustRaidChecklistState";

function getChecklistState() {
  try { return JSON.parse(localStorage.getItem(CHECKLIST_STORAGE_KEY)) || {}; }
  catch { return {}; }
}
function saveChecklistState(state) {
  localStorage.setItem(CHECKLIST_STORAGE_KEY, JSON.stringify(state));
}

function initChecklist() {
  const container = document.getElementById("checklistGroups");
  const state = getChecklistState();

  container.innerHTML = CHECKLIST_DATA.map((group, gi) => `
    <div class="check-group">
      <h3>${group.title}</h3>
      ${group.items.map((item, ii) => {
        const id = `${gi}-${ii}`;
        const checked = !!state[id];
        return `
          <div class="check-item ${checked ? "checked" : ""}" data-id="${id}">
            <div class="check-box"></div>
            <span class="label">${item}</span>
          </div>
        `;
      }).join("")}
    </div>
  `).join("");

  container.querySelectorAll(".check-item").forEach(el => {
    el.addEventListener("click", () => {
      el.classList.toggle("checked");
      const state = getChecklistState();
      state[el.dataset.id] = el.classList.contains("checked");
      saveChecklistState(state);
      updateProgress();
    });
  });

  updateProgress();
}

function updateProgress() {
  const items = document.querySelectorAll(".check-item");
  const total = items.length;
  const done = document.querySelectorAll(".check-item.checked").length;
  document.getElementById("progressFill").style.width = total ? `${(done / total) * 100}%` : "0%";
  document.getElementById("progressLabel").textContent = `${done} / ${total}`;
}

function resetChecklist() {
  localStorage.removeItem(CHECKLIST_STORAGE_KEY);
  initChecklist();
}
function renderRefTable() {
  const box = document.getElementById("refTable");
  if (!box) return;
  box.innerHTML = Object.entries(EXPLOSIVE_MAP).map(([expType, exp]) => {
    const raw = resolve(exp.key, 1);
    return `
      <div class="ref-item">
        <div class="ref-name">${exp.label}</div>
        <div class="ref-line">Сера: <b>${(raw.Sulfur || 0).toLocaleString("ru-RU")}</b></div>
        <div class="ref-line charcoal-line">Уголь: <b>${(raw.Charcoal || 0).toLocaleString("ru-RU")}</b></div>
      </div>
    `;
  }).join("");
} renderRefTable();